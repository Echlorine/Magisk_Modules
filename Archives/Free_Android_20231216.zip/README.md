# Free-Android
基于 [Magisk](https://github.com/topjohnwu/Magisk) 实现清理 Android 后台进程。

# 如何使用
1. 直接刷入模块重启即可使用。
2. 重启手机后可以修改模块目录下`AndroidFree`文件来实现自定义功能